<?php
/**
 * FEMINA Application - Hostinger phpMyAdmin REST API Backend
 * Location: public_html/Femina/index.php
 */

// Enable error reporting to prevent HTTP 500 white screen
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// -------------------------------------------------------------
// 1. Hostinger phpMyAdmin Database Credentials
// -------------------------------------------------------------
$db_host = "localhost";
$db_name = "u263420203_BSIT_inovex";
$db_user = "u263420203_BSIT_inovex";
$db_pass = "P4ssw0rd!123@";

$conn = null;

try {
    $conn = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Throwable $t1) {
    try {
        $conn = new PDO("mysql:host=127.0.0.1;dbname=$db_name;charset=utf8", $db_user, $db_pass);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (Throwable $t2) {
        try {
            $conn = new PDO("mysql:host=auth-db1277.hstgr.io;dbname=$db_name;charset=utf8", $db_user, $db_pass);
            $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (Throwable $t3) {
            echo json_encode(["status" => "error", "message" => "Database Connection Failed: " . $t3->getMessage()]);
            exit();
        }
    }
}

// Helper: Smart resolution for "Femina_" prefixed tables in phpMyAdmin
function resolveTableName($conn, $table) {
    $mapping = [
        "users" => ["Femina_users", "users"],
        "forum_posts" => ["Femina_forum_posts", "forum_posts"],
        "forum_comments" => ["Femina_forum_comments", "forum_comments"],
        "experts" => ["Femina_experts", "experts"],
        "consultations" => ["Femina_expert_consultations", "Femina_consultations", "consultations"]
    ];

    $candidates = isset($mapping[$table]) ? $mapping[$table] : [$table, "Femina_" . $table];
    foreach ($candidates as $cand) {
        try {
            $check = $conn->query("SHOW TABLES LIKE '$cand'");
            if ($check && $check->rowCount() > 0) {
                return $cand;
            }
        } catch(Throwable $e) {}
    }
    return $table;
}

$method = $_SERVER['REQUEST_METHOD'];

// -------------------------------------------------------------
// 2. GET Requests (Reading Tables)
// -------------------------------------------------------------
if ($method === 'GET') {
    $table_req = isset($_GET['table']) ? $_GET['table'] : 'forum_posts';
    $actual_table = resolveTableName($conn, $table_req);

    try {
        $stmt = $conn->prepare("SELECT * FROM `$actual_table` ORDER BY 1 DESC");
        $stmt->execute();
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode($results);
    } catch(Throwable $e) {
        echo json_encode(["status" => "error", "message" => $e->getMessage()]);
    }
}

// -------------------------------------------------------------
// 3. POST Requests (Writing & Creating Records)
// -------------------------------------------------------------
else if ($method === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    if ($action === 'create_post') {
        $user_id = isset($_POST['user_id']) ? $_POST['user_id'] : 'u_anon';
        $title = isset($_POST['title']) ? $_POST['title'] : 'Untitled Post';
        $content = isset($_POST['content']) ? $_POST['content'] : '';
        $category = isset($_POST['category']) ? $_POST['category'] : 'General';
        $post_id = "post_" . time();
        $target_table = resolveTableName($conn, 'forum_posts');

        try {
            $stmt = $conn->prepare("INSERT INTO `$target_table` (post_id, user_id, title, content, category, moderation_status, created_at) VALUES (?, ?, ?, ?, ?, 'APPROVED', NOW())");
            $stmt->execute([$post_id, $user_id, $title, $content, $category]);
            echo json_encode(["status" => "success", "message" => "Post created", "id" => $post_id]);
        } catch(Throwable $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
    }
    else if ($action === 'register_user') {
        $display_name = isset($_POST['display_name']) ? $_POST['display_name'] : 'New Member';
        $email = isset($_POST['email']) ? $_POST['email'] : '';
        $role = isset($_POST['role']) ? $_POST['role'] : 'user';
        $user_id = "user_" . time();
        $target_table = resolveTableName($conn, 'users');

        try {
            $stmt = $conn->prepare("INSERT INTO `$target_table` (user_id, display_name, email, role, account_status, created_at) VALUES (?, ?, ?, ?, 'ACTIVE', NOW())");
            $stmt->execute([$user_id, $display_name, $email, $role]);
            echo json_encode(["status" => "success", "message" => "User registered", "id" => $user_id]);
        } catch(Throwable $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
    }
    else {
        echo json_encode(["status" => "error", "message" => "Invalid action specified."]);
    }
}
?>
