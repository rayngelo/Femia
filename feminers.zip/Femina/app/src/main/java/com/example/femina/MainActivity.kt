package com.example.femina

import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.CircularProgressIndicator
import com.example.femina.network.RetrofitClient
import com.example.femina.network.User
import com.example.femina.network.ForumPost
import com.example.femina.network.ForumComment
import com.example.femina.network.Expert
import com.example.femina.network.Consultation
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MailOutline
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.ArrowBack
import com.example.femina.ui.theme.FeminaTheme
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.Dispatchers
import okhttp3.OkHttpClient
import okhttp3.Request

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContent {
            FeminaTheme {
                FeminaApp()
            }
        }
    }
}

@Composable
fun FeminaBackground(
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFFFFF6F8),
                        Color(0xFFF9EAEF)
                    )
                )
            )
    ) {
        content()
    }
}

@Composable
fun FeminaApp() {

    var selectedScreen by remember {
        mutableStateOf("Home")
    }

    // Tracks any screen opened on top of the 5 main bottom-nav tabs
    // (Mood Tracker, Settings, a chat, etc). Null means we're showing
    // the normal tabbed view instead.
    var activeSubScreen by remember {
        mutableStateOf<String?>(null)
    }

    // Posts created via the Post tab. Your API can only READ data
    // right now (no way to save a new post to the database), so new
    // posts are kept here and shown at the top of the feed until the
    // app closes. Once your API supports creating posts, replace this
    // with a real POST request and remove this local list.
    val localPosts = remember {
        mutableStateListOf<LocalPost>()
    }

    // Outer transition: fades/slides between "a sub-screen is open"
    // and "showing the normal tabs" - used for Mood Tracker, Settings,
    // chats, Profile options, the Professional portal, etc.
    AnimatedContent(
        targetState = activeSubScreen,
        transitionSpec = {
            (fadeIn(animationSpec = tween(220)) +
                    slideInVertically(animationSpec = tween(220)) { height -> height / 10 })
                .togetherWith(fadeOut(animationSpec = tween(150)))
        },
        label = "femina_overlay_transition"
    ) { sub ->

        if (sub != null) {
            when (sub) {
                "MoodTracker" -> {
                    MoodTrackerScreen(
                        onBack = { activeSubScreen = null }
                    )
                }

                "EditProfile" -> {
                    EditProfileScreen(
                        onBack = { activeSubScreen = null }
                    )
                }

                "MedicalHistory" -> {
                    MedicalHistoryScreen(
                        onBack = { activeSubScreen = null }
                    )
                }

                "Settings" -> {
                    SettingsScreen(
                        onBack = { activeSubScreen = null }
                    )
                }

                "HelpSupport" -> {
                    HelpSupportScreen(
                        onBack = { activeSubScreen = null }
                    )
                }

                "AccountPrivacy" -> {
                    AccountPrivacyScreen(
                        onBack = { activeSubScreen = null }
                    )
                }

                "Notifications" -> {
                    NotificationsScreen(
                        onBack = { activeSubScreen = null }
                    )
                }

                "Instructions" -> {
                    InstructionsScreen(
                        onBack = { activeSubScreen = null }
                    )
                }

                "CreateAccount" -> {
                    CreateAccountScreen(
                        onBack = { activeSubScreen = null }
                    )
                }

                "ProfessionalPortal" -> {
                    ProfessionalFlow(
                        onExit = { activeSubScreen = null }
                    )
                }

                "ChatFeminaAI" -> {
                    ChatScreen(
                        title = "Femina AI",
                        subtitle = "Your personal support assistant",
                        onBack = { activeSubScreen = null }
                    )
                }

                "ChatExperts" -> {
                    ChatScreen(
                        title = "Find Experts",
                        subtitle = "Connect with health professionals",
                        onBack = { activeSubScreen = null }
                    )
                }

                "ChatFriends" -> {
                    ChatScreen(
                        title = "Friends",
                        subtitle = "Chat with your community friends",
                        onBack = { activeSubScreen = null }
                    )
                }

                "TestUsers" -> {
                    TestUsersScreen(
                        onBack = { activeSubScreen = null }
                    )
                }
            }
        } else {

            Column(
                modifier = Modifier.fillMaxSize()
            ) {

                // Inner transition: a soft crossfade just for the tab
                // content, while the bottom nav bar stays put.
                Box(
                    modifier = Modifier.weight(1f)
                ) {
                    AnimatedContent(
                        targetState = selectedScreen,
                        transitionSpec = {
                            fadeIn(animationSpec = tween(180))
                                .togetherWith(fadeOut(animationSpec = tween(120)))
                        },
                        label = "femina_tab_transition"
                    ) { screen ->
                        when (screen) {
                            "Home" -> {
                                HomeScreen(
                                    onMoodTrackerClick = {
                                        activeSubScreen = "MoodTracker"
                                    },
                                    onTestUsersClick = {
                                        activeSubScreen = "TestUsers"
                                    },
                                    onNavigate = { destination ->
                                        activeSubScreen = destination
                                    },
                                    localPosts = localPosts
                                )
                            }

                            "Goals" -> {
                                GoalsScreen()
                            }

                            "Post" -> {
                                PostScreen(
                                    onPosted = { text ->
                                        localPosts.add(0, LocalPost(content = text))
                                        selectedScreen = "Home"
                                    }
                                )
                            }

                            "Messages" -> {
                                MessagesScreen(
                                    onNavigate = { destination ->
                                        activeSubScreen = destination
                                    }
                                )
                            }

                            "Profile" -> {
                                ProfileScreen(
                                    onNavigate = { destination ->
                                        activeSubScreen = destination
                                    }
                                )
                            }
                        }
                    }
                }

                BottomNavigationBar(
                    selectedScreen = selectedScreen,
                    onScreenSelected = {
                        selectedScreen = it
                    }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(
    onMoodTrackerClick: () -> Unit,
    onTestUsersClick: () -> Unit,
    onNavigate: (String) -> Unit,
    localPosts: List<LocalPost> = emptyList()
) {

    val feminaPink = Color(0xFFFF7695)
    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    var searchText by remember {
        mutableStateOf("")
    }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 20.dp,
                    end = 20.dp,
                    top = 45.dp,
                    bottom = 100.dp
                )
        ) {

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {

                Column {
                    Image(
                        painter = painterResource(R.drawable.femina_logo),
                        contentDescription = "Femina logo",
                        modifier = Modifier.height(58.dp)
                    )

                    Text(
                        text = "Your support community",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }

                Row {
                    IconButton(
                        onClick = { onNavigate("Notifications") }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications",
                            tint = darkPink
                        )
                    }

                    IconButton(
                        onClick = { onNavigate("Settings") }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = darkPink
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            OutlinedTextField(
                value = searchText,
                onValueChange = {
                    searchText = it
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(12.dp)
                    ),
                placeholder = {
                    Text("Search the community")
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "Search"
                    )
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = Color.White,
                    focusedContainerColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(25.dp))

            Text(
                text = "Welcome to FEMINA",
                color = textColor,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Connect, learn, and take care of your well-being with a supportive community.",
                color = Color.Gray,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(20.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 8.dp,
                        shape = RoundedCornerShape(20.dp),
                        clip = false
                    )
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Box(
                        modifier = Modifier
                            .size(45.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFCE4EC)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "♥",
                            color = darkPink,
                            fontSize = 22.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = "Daily Wellness",
                            color = textColor,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "Check in with yourself today",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(15.dp))

                Text(
                    text = "How are you feeling today?",
                    color = textColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Track your mood and symptoms to better understand your body.",
                    color = Color.Gray,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(15.dp))

                Button(
                    onClick = onMoodTrackerClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = feminaPink
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "Open Mood Tracker",
                        color = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = "Community Posts",
                color = darkPink,
                fontSize = 21.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(modifier = Modifier.height(12.dp))

            CommunityPostsFeed(localPosts = localPosts)
        }
    }
}

// A post created via the Post tab that isn't saved to the database
// (your API can't create rows yet, only read them). Kept in memory
// so the new post shows up immediately in the feed for a demo.
data class LocalPost(
    val content: String
)

@Composable
fun CommunityPostsFeed(
    localPosts: List<LocalPost> = emptyList()
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    var posts by remember { mutableStateOf<List<ForumPost>>(emptyList()) }
    var commentsByPost by remember { mutableStateOf<Map<String, List<ForumComment>>>(emptyMap()) }
    var authorNames by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var retryTrigger by remember { mutableStateOf(0) }

    val defaultSamplePosts = remember {
        listOf(
            ForumPost(
                post_id = "sample_1",
                user_id = "sample_u1",
                title = "Managing Hot Flashes Naturally",
                content = "Hi everyone! I've been trying cooling towels, hydration, and deep breathing exercises to help manage hot flashes. What natural remedies have worked best for you?",
                moderation_status = "APPROVED",
                created_at = "2026-03-20 10:00:00"
            ),
            ForumPost(
                post_id = "sample_2",
                user_id = "sample_u2",
                title = "Daily Self-Care Routine for Busy Days",
                content = "Even on chaotic days, taking 10 minutes for morning mindfulness and logging my mood here has made a huge difference in my mental clarity.",
                moderation_status = "APPROVED",
                created_at = "2026-03-22 14:30:00"
            ),
            ForumPost(
                post_id = "sample_3",
                user_id = "sample_u3",
                title = "Nutrition Tips for Boosting Energy",
                content = "Swapping afternoon sugary snacks for nuts and fresh berries helped reduce my brain fog dramatically. Highly recommend giving it a try!",
                moderation_status = "APPROVED",
                created_at = "2026-03-23 09:15:00"
            )
        )
    }

    val defaultSampleAuthors = remember {
        mapOf(
            "sample_u1" to "Sarah M.",
            "sample_u2" to "Elena Rostova",
            "sample_u3" to "Dr. Amara Chen"
        )
    }

    LaunchedEffect(retryTrigger) {
        isLoading = true
        errorMessage = null
        try {
            val fetchedPosts = RetrofitClient.apiService.getForumPosts()
            val fetchedUsers = RetrofitClient.apiService.getUsers()
            val fetchedComments = RetrofitClient.apiService.getForumComments()

            authorNames = fetchedUsers.associate { it.user_id to it.display_name }

            commentsByPost = fetchedComments
                .sortedBy { it.created_at }
                .groupBy { it.post_id }

            posts = fetchedPosts
                .filter { it.moderation_status.equals("APPROVED", ignoreCase = true) }
                .sortedByDescending { it.created_at }

            isLoading = false
        } catch (e: Exception) {
            val rawMsg = e.localizedMessage ?: ""
            val detailMsg = when {
                rawMsg.contains("BEGIN_ARRAY") && rawMsg.contains("BEGIN_OBJECT") ->
                    "The PHP script on Hostinger returned a JSON error object (likely database password mismatch in index.php)."
                rawMsg.contains("Unable to resolve host") ->
                    "Unable to reach server hostname."
                else -> rawMsg
            }
            errorMessage = "Server Notice: $detailMsg Showing sample community posts."
            posts = defaultSamplePosts
            authorNames = defaultSampleAuthors
            isLoading = false
        }
    }

    when {
        isLoading -> {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(30.dp),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = darkPink)
            }
        }

        else -> {
            Column(modifier = Modifier.fillMaxWidth()) {
                if (errorMessage != null) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color.White,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Offline Mode - Limited Connection",
                            color = darkPink,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = errorMessage ?: "",
                            color = Color.Gray,
                            fontSize = 12.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { retryTrigger++ },
                            colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = "RETRY CONNECTION", color = Color.White, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(15.dp))
                }

                if (posts.isEmpty() && localPosts.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color.White,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "No posts yet",
                            color = textColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Be the first to share something with the community.",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    localPosts.forEach { local ->
                        CommunityPostCard(
                            author = "You",
                            title = "New Post",
                            content = local.content
                        )
                        Spacer(modifier = Modifier.height(15.dp))
                    }

                    posts.forEachIndexed { index, post ->
                        CommunityPostCard(
                            author = authorNames[post.user_id] ?: "FEMINA Member",
                            title = post.title,
                            content = post.content,
                            comments = commentsByPost[post.post_id] ?: emptyList(),
                            authorNames = authorNames
                        )

                        if (index != posts.lastIndex) {
                            Spacer(modifier = Modifier.height(15.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CommunityPostCard(
    author: String,
    title: String,
    content: String,
    comments: List<ForumComment> = emptyList(),
    authorNames: Map<String, String> = emptyMap()
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)
    val context = androidx.compose.ui.platform.LocalContext.current

    var liked by remember { mutableStateOf(false) }
    var showComments by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 5.dp,
                shape = RoundedCornerShape(20.dp),
                clip = false
            )
            .background(
                color = Color.White,
                shape = RoundedCornerShape(20.dp)
            )
            .padding(18.dp)
    ) {

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {

            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFCE4EC)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "F",
                    color = darkPink,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = author,
                    color = textColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Text(
                    text = "Today",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
            text = title,
            color = textColor,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = content,
            color = Color.Gray,
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(15.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {

            Row(
                modifier = Modifier.clickable { liked = !liked },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Like",
                    tint = darkPink,
                    modifier = Modifier.size(20.dp)
                )

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = if (liked) "Liked" else "Like",
                    color = darkPink,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.width(20.dp))

            Text(
                text = if (comments.isEmpty()) "Comment" else "Comment (${comments.size})",
                color = if (showComments) darkPink else Color.Gray,
                fontSize = 12.sp,
                fontWeight = if (showComments) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.clickable { showComments = !showComments }
            )

            Spacer(modifier = Modifier.width(20.dp))

            Row(
                modifier = Modifier.clickable {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(
                            Intent.EXTRA_TEXT,
                            "$title\n\n$content\n\n- via FEMINA"
                        )
                    }
                    context.startActivity(
                        Intent.createChooser(shareIntent, "Share this post via")
                    )
                },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = Color.Gray,
                    modifier = Modifier.size(18.dp)
                )

                Spacer(modifier = Modifier.width(6.dp))

                Text(
                    text = "Share",
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }

        AnimatedVisibility(visible = showComments) {

            Column {

                Spacer(modifier = Modifier.height(14.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            color = Color(0xFFFAFAFA),
                            shape = RoundedCornerShape(14.dp)
                        )
                        .padding(14.dp)
                ) {

                    if (comments.isEmpty()) {
                        Text(
                            text = "No comments yet. Be the first to reply.",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    } else {
                        comments.forEachIndexed { index, comment ->

                            Row(verticalAlignment = Alignment.Top) {

                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFCE4EC)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = (authorNames[comment.user_id] ?: "F").take(1),
                                        color = darkPink,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column {
                                    Text(
                                        text = authorNames[comment.user_id] ?: "FEMINA Member",
                                        color = textColor,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )

                                    Spacer(modifier = Modifier.height(2.dp))

                                    Text(
                                        text = comment.content,
                                        color = Color.Gray,
                                        fontSize = 13.sp
                                    )
                                }
                            }

                            if (index != comments.lastIndex) {
                                Spacer(modifier = Modifier.height(10.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MoodTrackerScreen(
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val feminaPink = Color(0xFFFF7695)
    val textColor = Color(0xFF4A3540)

    var selectedMood by remember {
        mutableStateOf("")
    }

    val moods = listOf(
        "Overjoyed",
        "Happy",
        "Neutral",
        "Sad",
        "Anxious",
        "Angry"
    )

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {

                IconButton(
                    onClick = onBack
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = darkPink
                    )
                }

                Text(
                    text = "Mood Tracker",
                    color = darkPink,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(25.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {

                Text(
                    text = "How are you feeling today?",
                    color = textColor,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(15.dp))

                moods.forEach { mood ->

                    Button(
                        onClick = {
                            selectedMood = mood
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedMood == mood) {
                                feminaPink
                            } else {
                                Color(0xFFF5F5F5)
                            }
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = mood,
                            color = if (selectedMood == mood) {
                                Color.White
                            } else {
                                textColor
                            }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {

                Text(
                    text = "Symptoms",
                    color = textColor,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Hot Flashes  •  Fatigue  •  Brain Fog  •  Insomnia  •  Headache  •  Mood Swing",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {

                Text(
                    text = "Notes",
                    color = textColor,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = "",
                    onValueChange = {},
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    placeholder = {
                        Text("Write your notes here...")
                    },
                    shape = RoundedCornerShape(12.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onBack,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 30.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = darkPink
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = "SAVE MOOD",
                    color = Color.White
                )
            }
        }
    }
}

@Composable
fun GoalsScreen() {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 20.dp,
                    end = 20.dp,
                    top = 50.dp,
                    bottom = 100.dp
                )
        ) {

            Text(
                text = "Goals",
                color = darkPink,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Build healthy habits one day at a time.",
                color = textColor,
                fontSize = 14.sp
            )

            Spacer(modifier = Modifier.height(25.dp))

            GoalCard(
                title = "Sleep Support",
                task = "Get 7–8 hours of sleep"
            )

            Spacer(modifier = Modifier.height(15.dp))

            GoalCard(
                title = "Mental & Emotional",
                task = "Take 10 minutes for yourself"
            )

            Spacer(modifier = Modifier.height(15.dp))

            GoalCard(
                title = "Physical Health",
                task = "Walk or exercise for 20 minutes"
            )

            Spacer(modifier = Modifier.height(15.dp))

            GoalCard(
                title = "Nutrition",
                task = "Drink enough water today"
            )
        }
    }
}

@Composable
fun GoalCard(
    title: String,
    task: String
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    var completed by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 5.dp,
                shape = RoundedCornerShape(18.dp),
                clip = false
            )
            .background(
                color = Color.White,
                shape = RoundedCornerShape(18.dp)
            )
            .padding(18.dp)
    ) {

        Text(
            text = title,
            color = darkPink,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {

            Button(
                onClick = {
                    completed = !completed
                },
                modifier = Modifier.size(42.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (completed) {
                        darkPink
                    } else {
                        Color(0xFFFCE4EC)
                    }
                ),
                shape = CircleShape
            ) {
                Text(
                    text = if (completed) "✓" else "+",
                    color = if (completed) Color.White else darkPink,
                    fontSize = 18.sp
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = task,
                color = if (completed) Color.Gray else textColor,
                fontSize = 14.sp,
                fontWeight = if (completed) FontWeight.Normal else FontWeight.Medium
            )
        }
    }
}

@Composable
fun PostScreen(
    onPosted: (String) -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val feminaPink = Color(0xFFFF7695)
    val textColor = Color(0xFF4A3540)

    var postText by remember {
        mutableStateOf("")
    }

    val triviaList = remember {
        listOf(
            "💡 Did you know? Vitamin D and Calcium work together to support bone density during hormonal transitions.",
            "💡 Health Tip: Staying hydrated can reduce the frequency and severity of hot flashes and afternoon brain fog.",
            "💡 Mental Wellness: Taking just 5 deep, slow breaths can lower cortisol (stress hormone) levels within 60 seconds.",
            "💡 Sleep Fact: Keeping your bedroom temperature around 65-68°F (18-20°C) promotes deeper REM sleep and reduces night sweats.",
            "💡 Iron & Energy: Pair iron-rich foods (spinach, lentils) with Vitamin C (citrus, berries) to maximize absorption!",
            "💡 Movement Fact: 15 minutes of light walking after meals helps stabilize blood sugar and improves mood throughout the day."
        )
    }

    var currentTriviaIndex by remember { mutableStateOf(0) }
    val currentTrivia = triviaList[currentTriviaIndex]

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 20.dp,
                    end = 20.dp,
                    top = 50.dp,
                    bottom = 100.dp
                )
        ) {

            Text(
                text = "Community Post & Trivia",
                color = darkPink,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(modifier = Modifier.height(15.dp))

            // Daily Trivia Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "✨ Daily Health Trivia",
                        color = darkPink,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    TextButton(
                        onClick = {
                            currentTriviaIndex = (currentTriviaIndex + 1) % triviaList.size
                        }
                    ) {
                        Text("Next Trivia 🔄", color = feminaPink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = currentTrivia,
                    color = textColor,
                    fontSize = 14.sp,
                    lineHeight = 20.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                TextButton(
                    onClick = {
                        postText = "Reflecting on today's trivia:\n$currentTrivia\n\nMy thoughts: "
                    },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Reflect on this Trivia ✍️", color = darkPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Post Form Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(18.dp)
            ) {

                Text(
                    text = "Share Your Reflection or Update",
                    color = textColor,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Post a thought, question, or story to connect with the Femina community.",
                    color = Color.Gray,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = postText,
                    onValueChange = {
                        postText = it
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    placeholder = {
                        Text("Share your story or thoughts with the community...")
                    },
                    shape = RoundedCornerShape(16.dp)
                )

                Spacer(modifier = Modifier.height(15.dp))

                Button(
                    onClick = {
                        if (postText.isNotBlank()) {
                            val textToPost = postText
                            postText = ""
                            onPosted(textToPost)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = darkPink
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "POST TO COMMUNITY",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun MessagesScreen(
    onNavigate: (String) -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 20.dp,
                    end = 20.dp,
                    top = 50.dp,
                    bottom = 100.dp
                )
        ) {

            Text(
                text = "Messages",
                color = darkPink,
                fontSize = 28.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(modifier = Modifier.height(20.dp))

            MessageCard(
                name = "Femina AI",
                description = "Your personal support assistant",
                onClick = { onNavigate("ChatFeminaAI") }
            )

            Spacer(modifier = Modifier.height(12.dp))

            MessageCard(
                name = "Find Experts",
                description = "Connect with health professionals",
                onClick = { onNavigate("ChatExperts") }
            )

            Spacer(modifier = Modifier.height(12.dp))

            MessageCard(
                name = "Friends",
                description = "Chat with your community friends",
                onClick = { onNavigate("ChatFriends") }
            )
        }
    }
}

@Composable
fun MessageCard(
    name: String,
    description: String,
    onClick: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 5.dp,
                shape = RoundedCornerShape(18.dp),
                clip = false
            )
            .background(
                color = Color.White,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable { onClick() }
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        Box(
            modifier = Modifier
                .size(45.dp)
                .clip(CircleShape)
                .background(Color(0xFFFCE4EC)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.MailOutline,
                contentDescription = "Message",
                tint = darkPink
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column {
            Text(
                text = name,
                color = textColor,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = description,
                color = Color.Gray,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun ProfileScreen(
    onNavigate: (String) -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = 20.dp,
                    end = 20.dp,
                    top = 50.dp,
                    bottom = 100.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Box(
                modifier = Modifier
                    .size(95.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFCE4EC)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = "Profile",
                    tint = darkPink,
                    modifier = Modifier.size(55.dp)
                )
            }

            Spacer(modifier = Modifier.height(15.dp))

            Text(
                text = "My Profile",
                color = darkPink,
                fontSize = 25.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Text(
                text = "Manage your FEMINA account",
                color = textColor,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(25.dp))

            ProfileOption(
                title = "Database Test (Live Connection)",
                icon = Icons.Default.Search,
                onClick = { onNavigate("TestUsers") }
            )

            ProfileOption(
                title = "How to Use FEMINA",
                icon = Icons.Default.Info,
                onClick = { onNavigate("Instructions") }
            )

            ProfileOption(
                title = "Create Account (Preview)",
                icon = Icons.Default.Person,
                onClick = { onNavigate("CreateAccount") }
            )

            ProfileOption(
                title = "Professional / Expert Portal",
                icon = Icons.Default.FavoriteBorder,
                onClick = { onNavigate("ProfessionalPortal") }
            )

            ProfileOption(
                title = "Edit Profile",
                icon = Icons.Default.Edit,
                onClick = { onNavigate("EditProfile") }
            )

            ProfileOption(
                title = "Medical History & Notes",
                icon = Icons.Default.FavoriteBorder,
                onClick = { onNavigate("MedicalHistory") }
            )

            ProfileOption(
                title = "Settings",
                icon = Icons.Default.Settings,
                onClick = { onNavigate("Settings") }
            )

            ProfileOption(
                title = "Help & Support",
                icon = Icons.Default.Flag,
                onClick = { onNavigate("HelpSupport") }
            )

            ProfileOption(
                title = "Account & Privacy",
                icon = Icons.Default.Person,
                onClick = { onNavigate("AccountPrivacy") }
            )
        }
    }
}

@Composable
fun ProfileOption(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .background(
                color = Color.White,
                shape = RoundedCornerShape(15.dp)
            )
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        Icon(
            imageVector = icon,
            contentDescription = title,
            tint = darkPink
        )

        Spacer(modifier = Modifier.width(15.dp))

        Text(
            text = title,
            color = textColor,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun BottomNavigationBar(
    selectedScreen: String,
    onScreenSelected: (String) -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color.White,
        shadowElevation = 12.dp,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    vertical = 12.dp,
                    horizontal = 8.dp
                ),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {

            NavigationItem(
                label = "Home",
                icon = Icons.Default.Home,
                selected = selectedScreen == "Home",
                onClick = {
                    onScreenSelected("Home")
                }
            )

            NavigationItem(
                label = "Goals",
                icon = Icons.Default.Flag,
                selected = selectedScreen == "Goals",
                onClick = {
                    onScreenSelected("Goals")
                }
            )

            NavigationItem(
                label = "Post",
                icon = Icons.Default.Add,
                selected = selectedScreen == "Post",
                onClick = {
                    onScreenSelected("Post")
                }
            )

            NavigationItem(
                label = "Messages",
                icon = Icons.Default.MailOutline,
                selected = selectedScreen == "Messages",
                onClick = {
                    onScreenSelected("Messages")
                }
            )

            NavigationItem(
                label = "Profile",
                icon = Icons.Default.Person,
                selected = selectedScreen == "Profile",
                onClick = {
                    onScreenSelected("Profile")
                }
            )
        }
    }
}

@Composable
fun NavigationItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        IconButton(
            onClick = onClick
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) darkPink else Color.Gray
            )
        }

        Text(
            text = label,
            color = if (selected) darkPink else Color.Gray,
            fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// Generic screen used for Profile destinations that don't have their
// ============================================================
// SHARED PIECES used by the screens below
// ============================================================

// Standard back-arrow + title header used on every sub-screen.
@Composable
fun ScreenHeader(
    title: String,
    onBack: () -> Unit
) {
    val darkPink = Color(0xFF9B4D6A)

    Row(
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = darkPink
            )
        }

        Text(
            text = title,
            color = darkPink,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.3.sp
        )
    }
}

// White rounded card used to group content on every sub-screen.
@Composable
fun FeminaCard(
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(
                elevation = 6.dp,
                shape = RoundedCornerShape(20.dp),
                clip = false
            )
            .background(
                color = Color.White,
                shape = RoundedCornerShape(20.dp)
            )
            .padding(18.dp),
        content = content
    )
}

// Label + text input pair used on the form screens.
@Composable
fun FormField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    singleLine: Boolean = true,
    heightDp: Int = 0
) {
    val textColor = Color(0xFF4A3540)

    Column(modifier = Modifier.fillMaxWidth()) {

        Text(
            text = label,
            color = textColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            modifier = if (heightDp > 0) {
                Modifier
                    .fillMaxWidth()
                    .height(heightDp.dp)
            } else {
                Modifier.fillMaxWidth()
            },
            placeholder = { Text(placeholder) },
            singleLine = singleLine,
            shape = RoundedCornerShape(12.dp),
            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color(0xFFFAFAFA),
                focusedContainerColor = Color.White
            )
        )
    }
}

// A row with a label, description, and an on/off switch.
@Composable
fun SettingToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = textColor,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = description,
                color = Color.Gray,
                fontSize = 12.sp
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = darkPink
            )
        )
    }
}

// ============================================================
// EDIT PROFILE
// ============================================================
@Composable
fun EditProfileScreen(
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    var displayName by remember { mutableStateOf("Maria Santos") }
    var email by remember { mutableStateOf("maria.santos@example.com") }
    var age by remember { mutableStateOf("34") }
    var bio by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "Edit Profile", onBack = onBack)

            Spacer(modifier = Modifier.height(20.dp))

            // Avatar
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFCE4EC)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profile photo",
                            tint = darkPink,
                            modifier = Modifier.size(50.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Change Photo",
                        color = darkPink,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { }
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            FeminaCard {
                Text(
                    text = "Personal Information",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(14.dp))

                FormField(
                    label = "Display Name",
                    value = displayName,
                    onValueChange = { displayName = it; saved = false },
                    placeholder = "Your name"
                )

                Spacer(modifier = Modifier.height(12.dp))

                FormField(
                    label = "Email",
                    value = email,
                    onValueChange = { email = it; saved = false },
                    placeholder = "you@example.com"
                )

                Spacer(modifier = Modifier.height(12.dp))

                FormField(
                    label = "Age",
                    value = age,
                    onValueChange = { age = it; saved = false },
                    placeholder = "Your age"
                )

                Spacer(modifier = Modifier.height(12.dp))

                FormField(
                    label = "About Me",
                    value = bio,
                    onValueChange = { bio = it; saved = false },
                    placeholder = "Tell the community a little about yourself...",
                    singleLine = false,
                    heightDp = 110
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = { saved = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (saved) "SAVED" else "SAVE CHANGES",
                    color = Color.White
                )
            }

            if (saved) {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Your profile has been updated.",
                    color = darkPink,
                    fontSize = 13.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ============================================================
// MEDICAL HISTORY & NOTES
// ============================================================
@Composable
fun MedicalHistoryScreen(
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val feminaPink = Color(0xFFFF7695)
    val textColor = Color(0xFF4A3540)

    val conditionOptions = listOf(
        "Perimenopause",
        "Menopause",
        "PCOS",
        "Endometriosis",
        "Thyroid condition",
        "Hypertension",
        "Diabetes"
    )

    var selectedConditions by remember { mutableStateOf(setOf<String>()) }
    var medications by remember { mutableStateOf("") }
    var allergies by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf(false) }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "Medical History & Notes", onBack = onBack)

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Kept private and only visible to you.",
                color = textColor,
                fontSize = 13.sp,
                modifier = Modifier.padding(start = 12.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            FeminaCard {
                Text(
                    text = "Health Conditions",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Tap any that apply to you.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                conditionOptions.forEach { condition ->

                    val isSelected = selectedConditions.contains(condition)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(
                                color = if (isSelected) feminaPink else Color(0xFFF5F5F5),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                selectedConditions = if (isSelected) {
                                    selectedConditions - condition
                                } else {
                                    selectedConditions + condition
                                }
                                saved = false
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isSelected) "✓" else "○",
                            color = if (isSelected) Color.White else darkPink,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.width(10.dp))

                        Text(
                            text = condition,
                            color = if (isSelected) Color.White else textColor,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            FeminaCard {
                Text(
                    text = "Medications & Allergies",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(14.dp))

                FormField(
                    label = "Current Medications",
                    value = medications,
                    onValueChange = { medications = it; saved = false },
                    placeholder = "List anything you take regularly...",
                    singleLine = false,
                    heightDp = 100
                )

                Spacer(modifier = Modifier.height(12.dp))

                FormField(
                    label = "Allergies",
                    value = allergies,
                    onValueChange = { allergies = it; saved = false },
                    placeholder = "Food, medication, or other allergies...",
                    singleLine = false,
                    heightDp = 100
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            FeminaCard {
                Text(
                    text = "Personal Notes",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Anything you'd want to remember or share with a doctor.",
                    color = Color.Gray,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it; saved = false },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp),
                    placeholder = { Text("Write your notes here...") },
                    shape = RoundedCornerShape(12.dp),
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = Color(0xFFFAFAFA),
                        focusedContainerColor = Color.White
                    )
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = { saved = true },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    text = if (saved) "SAVED" else "SAVE RECORD",
                    color = Color.White
                )
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ============================================================
// SETTINGS
// ============================================================
@Composable
fun SettingsScreen(
    onBack: () -> Unit
) {

    val textColor = Color(0xFF4A3540)

    var pushNotifications by remember { mutableStateOf(true) }
    var moodReminders by remember { mutableStateOf(true) }
    var goalReminders by remember { mutableStateOf(false) }
    var communityUpdates by remember { mutableStateOf(true) }
    var soundEffects by remember { mutableStateOf(false) }
    var largeText by remember { mutableStateOf(false) }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "Settings", onBack = onBack)

            Spacer(modifier = Modifier.height(20.dp))

            FeminaCard {
                Text(
                    text = "Notifications",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                SettingToggleRow(
                    title = "Push Notifications",
                    description = "Allow FEMINA to send you alerts",
                    checked = pushNotifications,
                    onCheckedChange = { pushNotifications = it }
                )

                SettingToggleRow(
                    title = "Daily Mood Reminder",
                    description = "A gentle nudge to check in",
                    checked = moodReminders,
                    onCheckedChange = { moodReminders = it }
                )

                SettingToggleRow(
                    title = "Goal Reminders",
                    description = "Remind me about my daily goals",
                    checked = goalReminders,
                    onCheckedChange = { goalReminders = it }
                )

                SettingToggleRow(
                    title = "Community Updates",
                    description = "New posts and replies",
                    checked = communityUpdates,
                    onCheckedChange = { communityUpdates = it }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            FeminaCard {
                Text(
                    text = "App Preferences",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                SettingToggleRow(
                    title = "Sound Effects",
                    description = "Play sounds on actions",
                    checked = soundEffects,
                    onCheckedChange = { soundEffects = it }
                )

                SettingToggleRow(
                    title = "Larger Text",
                    description = "Increase text size for readability",
                    checked = largeText,
                    onCheckedChange = { largeText = it }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            FeminaCard {
                Text(
                    text = "About",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                InfoRow(label = "App Version", value = "1.0.0")
                InfoRow(label = "Last Updated", value = "September 2026")
                InfoRow(label = "Developed by", value = "FEMINA Team")
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// Small label-on-left, value-on-right row.
@Composable
fun InfoRow(
    label: String,
    value: String
) {
    val textColor = Color(0xFF4A3540)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = textColor,
            fontSize = 14.sp
        )

        Text(
            text = value,
            color = Color.Gray,
            fontSize = 14.sp
        )
    }
}

// ============================================================
// HELP & SUPPORT
// ============================================================
@Composable
fun HelpSupportScreen(
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)
    val context = androidx.compose.ui.platform.LocalContext.current

    val faqs = listOf(
        "How do I track my mood?" to
                "Open the Home tab and tap Open Mood Tracker. Choose how you're feeling, add any symptoms, write a note, then tap Save Mood.",
        "Is my medical information private?" to
                "Yes. Anything you enter under Medical History & Notes is stored for your eyes only and is never shown on your public profile or in the community feed.",
        "How do I connect with a health professional?" to
                "Go to the Messages tab and tap Find Experts. You'll be able to browse verified professionals and start a conversation.",
        "Can I edit or delete a post?" to
                "Yes. Open the post from the community feed and use the options menu to edit or remove it.",
        "How do I set daily goals?" to
                "Tap the Goals tab. Each card has a circle button you can tap to mark that goal complete for the day."
    )

    var expandedIndex by remember { mutableStateOf(-1) }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "Help & Support", onBack = onBack)

            Spacer(modifier = Modifier.height(20.dp))

            FeminaCard {
                Text(
                    text = "Frequently Asked Questions",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                faqs.forEachIndexed { index, faq ->

                    val isExpanded = expandedIndex == index

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .background(
                                color = Color(0xFFFAFAFA),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable {
                                expandedIndex = if (isExpanded) -1 else index
                            }
                            .padding(14.dp)
                    ) {

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = faq.first,
                                color = textColor,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.weight(1f)
                            )

                            Text(
                                text = if (isExpanded) "−" else "+",
                                color = darkPink,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        AnimatedVisibility(visible = isExpanded) {
                            Column {
                                Spacer(modifier = Modifier.height(8.dp))

                                Text(
                                    text = faq.second,
                                    color = Color.Gray,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            FeminaCard {
                Text(
                    text = "Still need help?",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Our support team usually replies within 24 hours.",
                    color = Color.Gray,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = {
                        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
                            data = android.net.Uri.parse("mailto:support@femina.app")
                            putExtra(Intent.EXTRA_SUBJECT, "FEMINA Support Request")
                        }
                        context.startActivity(emailIntent)
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = "EMAIL SUPPORT", color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            FeminaCard {
                Text(
                    text = "In Crisis?",
                    color = darkPink,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "FEMINA is not an emergency service. If you or someone you know needs urgent help, please contact your local emergency number or a crisis helpline right away.",
                    color = Color.Gray,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ============================================================
// ACCOUNT & PRIVACY
// ============================================================
@Composable
fun AccountPrivacyScreen(
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    var publicProfile by remember { mutableStateOf(true) }
    var showEmail by remember { mutableStateOf(false) }
    var allowMessages by remember { mutableStateOf(true) }
    var anonymousPosting by remember { mutableStateOf(false) }
    var shareAnalytics by remember { mutableStateOf(true) }

    var showDeleteConfirm by remember { mutableStateOf(false) }
    var showChangePassword by remember { mutableStateOf(false) }
    var showLogoutConfirm by remember { mutableStateOf(false) }

    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var confirmNewPassword by remember { mutableStateOf("") }
    var passwordError by remember { mutableStateOf<String?>(null) }
    var passwordChanged by remember { mutableStateOf(false) }

    val context = androidx.compose.ui.platform.LocalContext.current

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "Account & Privacy", onBack = onBack)

            Spacer(modifier = Modifier.height(20.dp))

            FeminaCard {
                Text(
                    text = "Account",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                InfoRow(label = "Display Name", value = "Maria Santos")
                InfoRow(label = "Email", value = "maria.santos@example.com")
                InfoRow(label = "Status", value = "Active")
                InfoRow(label = "Member Since", value = "August 2026")
            }

            Spacer(modifier = Modifier.height(16.dp))

            FeminaCard {
                Text(
                    text = "Privacy",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                SettingToggleRow(
                    title = "Public Profile",
                    description = "Let other members view your profile",
                    checked = publicProfile,
                    onCheckedChange = { publicProfile = it }
                )

                SettingToggleRow(
                    title = "Show Email",
                    description = "Display your email on your profile",
                    checked = showEmail,
                    onCheckedChange = { showEmail = it }
                )

                SettingToggleRow(
                    title = "Allow Direct Messages",
                    description = "Let members start a chat with you",
                    checked = allowMessages,
                    onCheckedChange = { allowMessages = it }
                )

                SettingToggleRow(
                    title = "Post Anonymously",
                    description = "Hide your name on community posts",
                    checked = anonymousPosting,
                    onCheckedChange = { anonymousPosting = it }
                )

                SettingToggleRow(
                    title = "Share Usage Data",
                    description = "Help us improve FEMINA",
                    checked = shareAnalytics,
                    onCheckedChange = { shareAnalytics = it }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            FeminaCard {
                Text(
                    text = "Security",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Change Password",
                    color = darkPink,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showChangePassword = !showChangePassword
                            passwordChanged = false
                            passwordError = null
                        }
                        .padding(vertical = 8.dp)
                )

                if (showChangePassword) {

                    Spacer(modifier = Modifier.height(8.dp))

                    if (passwordChanged) {
                        Text(
                            text = "Your password has been updated.",
                            color = darkPink,
                            fontSize = 13.sp
                        )
                    } else {
                        OutlinedTextField(
                            value = currentPassword,
                            onValueChange = { currentPassword = it; passwordError = null },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Current password") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newPassword,
                            onValueChange = { newPassword = it; passwordError = null },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("New password (min 6 characters)") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = confirmNewPassword,
                            onValueChange = { confirmNewPassword = it; passwordError = null },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Confirm new password") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        if (passwordError != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = passwordError ?: "",
                                color = Color(0xFFC62828),
                                fontSize = 12.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = {
                                when {
                                    currentPassword.isBlank() || newPassword.isBlank() -> {
                                        passwordError = "Please fill in all fields."
                                    }
                                    newPassword.length < 6 -> {
                                        passwordError = "New password must be at least 6 characters."
                                    }
                                    newPassword != confirmNewPassword -> {
                                        passwordError = "New passwords don't match."
                                    }
                                    else -> {
                                        passwordChanged = true
                                        currentPassword = ""
                                        newPassword = ""
                                        confirmNewPassword = ""
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = "UPDATE PASSWORD", color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                }

                Text(
                    text = "Download My Data",
                    color = darkPink,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            val summary = """
                                FEMINA Account Data Export

                                Name: Maria Santos
                                Email: maria.santos@example.com
                                Status: Active
                                Member Since: August 2026

                                Privacy Settings:
                                Public Profile: $publicProfile
                                Show Email: $showEmail
                                Allow Direct Messages: $allowMessages
                                Post Anonymously: $anonymousPosting
                                Share Usage Data: $shareAnalytics
                            """.trimIndent()

                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "My FEMINA Data")
                                putExtra(Intent.EXTRA_TEXT, summary)
                            }
                            context.startActivity(
                                Intent.createChooser(shareIntent, "Save or share your data via")
                            )
                        }
                        .padding(vertical = 8.dp)
                )

                if (!showLogoutConfirm) {
                    Text(
                        text = "Log Out",
                        color = darkPink,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showLogoutConfirm = true }
                            .padding(vertical = 8.dp)
                    )
                } else {
                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Log out of FEMINA?",
                        color = textColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { showLogoutConfirm = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFF5F5F5)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = "Cancel", color = textColor)
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Button(
                            onClick = {
                                showLogoutConfirm = false
                                onBack()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = "Log Out", color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            FeminaCard {
                Text(
                    text = "Delete Account",
                    color = Color(0xFFC62828),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "This permanently removes your account and all your data. This cannot be undone.",
                    color = Color.Gray,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (!showDeleteConfirm) {
                    Button(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFFFEBEE)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = "Delete My Account", color = Color(0xFFC62828))
                    }
                } else {
                    Text(
                        text = "Are you sure?",
                        color = textColor,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { showDeleteConfirm = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFF5F5F5)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = "Cancel", color = textColor)
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Button(
                            onClick = { showDeleteConfirm = false },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFC62828)
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(text = "Confirm", color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ============================================================
// NOTIFICATIONS
// ============================================================
// INSTRUCTIONS / HOW TO USE
// ============================================================
data class InstructionStep(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val title: String,
    val description: String
)

// ============================================================
// PROFESSIONAL / EXPERT PORTAL
// ============================================================

// Manages the internal steps of the professional flow (Login,
// Signup/Apply, Verification Pending, Dashboard) so FeminaApp only
// needs one routing case for the whole thing.
@Composable
fun ProfessionalFlow(
    onExit: () -> Unit
) {
    var screen by remember { mutableStateOf("Login") }
    var loggedInExpert by remember { mutableStateOf<Expert?>(null) }
    var justAppliedName by remember { mutableStateOf("") }

    when (screen) {
        "Login" -> {
            ProfessionalLoginScreen(
                onBack = onExit,
                onLoginSuccess = { expert ->
                    loggedInExpert = expert
                    screen = if (expert.verification_status.equals("APPROVED", ignoreCase = true)) {
                        "Dashboard"
                    } else {
                        "Pending"
                    }
                },
                onGoToSignup = { screen = "Signup" }
            )
        }

        "Signup" -> {
            ProfessionalVerificationScreen(
                onBack = { screen = "Login" },
                onSubmitted = { name ->
                    justAppliedName = name
                    screen = "PendingNew"
                }
            )
        }

        "Pending" -> {
            VerificationPendingScreen(
                expert = loggedInExpert,
                submittedName = null,
                onBack = {
                    loggedInExpert = null
                    screen = "Login"
                },
                onApproved = { updatedExpert ->
                    loggedInExpert = updatedExpert
                    screen = "Dashboard"
                }
            )
        }

        "PendingNew" -> {
            VerificationPendingScreen(
                expert = null,
                submittedName = justAppliedName,
                onBack = { screen = "Login" },
                onApproved = {}
            )
        }

        "Dashboard" -> {
            ProfessionalDashboardScreen(
                expert = loggedInExpert,
                onLogout = {
                    loggedInExpert = null
                    screen = "Login"
                },
                onBack = onExit
            )
        }
    }
}

// ------------------------------------------------------------
// PROFESSIONAL LOGIN
// ------------------------------------------------------------
@Composable
fun ProfessionalLoginScreen(
    onBack: () -> Unit,
    onLoginSuccess: (Expert) -> Unit,
    onGoToSignup: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val feminaPink = Color(0xFFFF7695)
    val textColor = Color(0xFF4A3540)

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isChecking by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val coroutineScope = rememberCoroutineScope()

    fun attemptLogin() {
        errorMessage = null

        if (email.isBlank() || password.isBlank()) {
            errorMessage = "Please enter your email and password."
            return
        }

        isChecking = true

        coroutineScope.launch {
            try {
                val experts = RetrofitClient.apiService.getExperts()
                val match = experts.firstOrNull {
                    it.email.isNotBlank() && it.email.equals(email.trim(), ignoreCase = true)
                }

                delay(400)
                isChecking = false

                if (match != null) {
                    onLoginSuccess(match)
                } else {
                    errorMessage = "No professional account found with that email."
                }
            } catch (e: Exception) {
                errorMessage = "Couldn't reach the server. Check your connection."
                isChecking = false
            }
        }
    }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "Professional Login", onBack = onBack)

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "For verified health professionals using FEMINA.",
                color = Color.Gray,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 12.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFCE4EC)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.FavoriteBorder,
                        contentDescription = null,
                        tint = darkPink,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            FeminaCard {

                FormField(
                    label = "Email",
                    value = email,
                    onValueChange = { email = it; errorMessage = null },
                    placeholder = "you@clinic.com"
                )

                Spacer(modifier = Modifier.height(12.dp))

                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "Password",
                        color = textColor,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it; errorMessage = null },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Your password") },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        shape = RoundedCornerShape(12.dp)
                    )
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = Color(0xFFC62828),
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { attemptLogin() },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isChecking,
                    colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (isChecking) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    } else {
                        Text(text = "LOG IN", color = Color.White)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "Not registered yet? ",
                    color = textColor,
                    fontSize = 13.sp
                )

                Text(
                    text = "Apply as a Professional",
                    color = feminaPink,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onGoToSignup() }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Demo Accounts Card for Quick Access
            FeminaCard {
                Text(
                    text = "🩺 One-Tap Demo Doctor Login",
                    color = darkPink,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Tap a doctor below to instantly preview the Professional App View:",
                    color = Color.Gray,
                    fontSize = 12.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                val demoDoctors = remember {
                    listOf(
                        Expert(
                            expert_id = "exp_101",
                            name = "Dr. Amara Chen, MD",
                            email = "dr.chen@femina.org",
                            specialty = "OB-GYN & Women's Health",
                            license_number = "MD-8492041",
                            license_document_url = "",
                            id_document_url = "",
                            verification_status = "APPROVED",
                            bio = "Board-certified OB-GYN specializing in reproductive health, menopause management, and holistic wellness.",
                            profile_photo_url = null,
                            created_at = "2026-01-01",
                            availability_status = "AVAILABLE"
                        ),
                        Expert(
                            expert_id = "exp_102",
                            name = "Dr. Elena Martinez, MD",
                            email = "dr.martinez@femina.org",
                            specialty = "Endocrinology & Hormonal Health",
                            license_number = "MD-9201482",
                            license_document_url = "",
                            id_document_url = "",
                            verification_status = "APPROVED",
                            bio = "Endocrinologist focusing on thyroid care, hormonal balance, and metabolic health for women.",
                            profile_photo_url = null,
                            created_at = "2026-01-01",
                            availability_status = "BUSY"
                        )
                    )
                }

                demoDoctors.forEach { demo ->
                    Button(
                        onClick = { onLoginSuccess(demo) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFCE4EC)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = "🩺 Log in as ${demo.name}",
                            color = darkPink,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ------------------------------------------------------------
// PROFESSIONAL VERIFICATION (apply form)
// ------------------------------------------------------------
@Composable
fun ProfessionalVerificationScreen(
    onBack: () -> Unit,
    onSubmitted: (String) -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var specialty by remember { mutableStateOf("") }
    var licenseNumber by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "Apply as a Professional", onBack = onBack)

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Preview form - submissions aren't saved to the database yet, since your API can't create new rows.",
                color = Color.Gray,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 12.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            FeminaCard {

                Text(
                    text = "Your Details",
                    color = textColor,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(14.dp))

                FormField(
                    label = "Full Name",
                    value = name,
                    onValueChange = { name = it; errorMessage = null },
                    placeholder = "Dr. Jane Smith"
                )

                Spacer(modifier = Modifier.height(12.dp))

                FormField(
                    label = "Email",
                    value = email,
                    onValueChange = { email = it; errorMessage = null },
                    placeholder = "you@clinic.com"
                )

                Spacer(modifier = Modifier.height(12.dp))

                FormField(
                    label = "Specialty",
                    value = specialty,
                    onValueChange = { specialty = it; errorMessage = null },
                    placeholder = "e.g. Gynecology, Nutrition"
                )

                Spacer(modifier = Modifier.height(12.dp))

                FormField(
                    label = "License Number",
                    value = licenseNumber,
                    onValueChange = { licenseNumber = it; errorMessage = null },
                    placeholder = "LIC-000000"
                )

                Spacer(modifier = Modifier.height(12.dp))

                FormField(
                    label = "Short Bio",
                    value = bio,
                    onValueChange = { bio = it; errorMessage = null },
                    placeholder = "Tell patients about your background...",
                    singleLine = false,
                    heightDp = 100
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Upload license & ID documents",
                    color = darkPink,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { }
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = errorMessage ?: "",
                        color = Color(0xFFC62828),
                        fontSize = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        when {
                            name.isBlank() || email.isBlank() || specialty.isBlank() || licenseNumber.isBlank() -> {
                                errorMessage = "Please fill in all required fields."
                            }
                            !email.contains("@") -> {
                                errorMessage = "Please enter a valid email address."
                            }
                            else -> {
                                onSubmitted(name)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = "SUBMIT APPLICATION", color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ------------------------------------------------------------
// VERIFICATION PENDING
// ------------------------------------------------------------
@Composable
fun VerificationPendingScreen(
    expert: Expert?,
    submittedName: String?,
    onBack: () -> Unit,
    onApproved: (Expert) -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    var isRefreshing by remember { mutableStateOf(false) }
    var refreshMessage by remember { mutableStateOf<String?>(null) }

    val coroutineScope = rememberCoroutineScope()
    val displayName = expert?.name ?: submittedName ?: "there"

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "Verification Pending", onBack = onBack)

            Spacer(modifier = Modifier.height(20.dp))

            FeminaCard {

                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(70.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFCE4EC)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "⏳",
                                fontSize = 30.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "Hi $displayName,",
                            color = textColor,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Your application is under review. Our team verifies license and ID documents before approving new professionals.",
                            color = Color.Gray,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            if (expert != null) {

                Spacer(modifier = Modifier.height(16.dp))

                FeminaCard {
                    Text(
                        text = "Application Details",
                        color = textColor,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    InfoRow(label = "Specialty", value = expert.specialty)
                    InfoRow(label = "License Number", value = expert.license_number)
                    InfoRow(label = "Status", value = expert.verification_status)
                    InfoRow(label = "Submitted", value = expert.created_at)
                }

                Spacer(modifier = Modifier.height(16.dp))

                FeminaCard {

                    Text(
                        text = "Check for updates",
                        color = textColor,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "If your account has since been approved, refresh to unlock your dashboard.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )

                    if (refreshMessage != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = refreshMessage ?: "",
                            color = darkPink,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            isRefreshing = true
                            refreshMessage = null
                            coroutineScope.launch {
                                try {
                                    val experts = RetrofitClient.apiService.getExperts()
                                    val updated = experts.firstOrNull { it.expert_id == expert.expert_id }

                                    delay(500)
                                    isRefreshing = false

                                    if (updated != null && updated.verification_status.equals("APPROVED", ignoreCase = true)) {
                                        onApproved(updated)
                                    } else {
                                        refreshMessage = "Still under review. Check back later."
                                    }
                                } catch (e: Exception) {
                                    isRefreshing = false
                                    refreshMessage = "Couldn't check status. Try again."
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isRefreshing,
                        colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isRefreshing) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        } else {
                            Text(text = "REFRESH STATUS", color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ------------------------------------------------------------
// PROFESSIONAL DASHBOARD
// ------------------------------------------------------------
@Composable
fun ProfessionalDashboardScreen(
    expert: Expert?,
    onLogout: () -> Unit,
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val feminaPink = Color(0xFFFF7695)
    val textColor = Color(0xFF4A3540)

    var patientConsultations by remember { mutableStateOf<List<Consultation>>(emptyList()) }
    var patientNames by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var availability by remember { mutableStateOf(expert?.availability_status ?: "AVAILABLE") }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var doctorNotes by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var editingConsultationId by remember { mutableStateOf<String?>(null) }
    var noteInputText by remember { mutableStateOf("") }

    val defaultSampleConsultations = remember {
        listOf(
            Consultation(
                consultation_id = "c_101",
                user_id = "u_101",
                expert_id = expert?.expert_id ?: "exp_101",
                scheduled_at = "Today, 2:30 PM",
                status = "PENDING",
                user_concern = "Seeking medical advice for managing hormonal symptoms, hot flashes, and sleep disturbances."
            ),
            Consultation(
                consultation_id = "c_102",
                user_id = "u_102",
                expert_id = expert?.expert_id ?: "exp_101",
                scheduled_at = "Tomorrow, 10:00 AM",
                status = "CONFIRMED",
                user_concern = "Follow-up discussion on nutrition plan, iron supplements, and energy levels."
            ),
            Consultation(
                consultation_id = "c_103",
                user_id = "u_103",
                expert_id = expert?.expert_id ?: "exp_101",
                scheduled_at = "March 28, 4:00 PM",
                status = "CONFIRMED",
                user_concern = "Guidance requested on stress management techniques and morning fatigue routines."
            )
        )
    }

    val defaultSamplePatientNames = remember {
        mapOf(
            "u_101" to "Maria Santos",
            "u_102" to "Jessica Taylor",
            "u_103" to "Hannah Lee"
        )
    }

    LaunchedEffect(expert?.expert_id) {
        if (expert == null) {
            isLoading = false
            return@LaunchedEffect
        }

        try {
            val allConsultations = RetrofitClient.apiService.getConsultations()
            val allUsers = RetrofitClient.apiService.getUsers()

            patientNames = allUsers.associate { it.user_id to it.display_name }

            val filtered = allConsultations
                .filter { it.expert_id == expert.expert_id }
                .sortedBy { it.scheduled_at }

            if (filtered.isNotEmpty()) {
                patientConsultations = filtered
            } else {
                patientConsultations = defaultSampleConsultations
                patientNames = defaultSamplePatientNames
            }

            isLoading = false
        } catch (e: Exception) {
            patientConsultations = defaultSampleConsultations
            patientNames = defaultSamplePatientNames
            isLoading = false
        }
    }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ScreenHeader(title = "Professional Portal", onBack = onBack)

                Text(
                    text = "Log Out",
                    color = darkPink,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onLogout() }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (expert == null) {
                FeminaCard {
                    Text(
                        text = "No professional session found.",
                        color = textColor,
                        fontSize = 14.sp
                    )
                }
                return@Column
            }

            // Doctor Profile Header Card
            FeminaCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFCE4EC)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = expert.name.take(1),
                            color = darkPink,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = expert.name,
                                color = textColor,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )

                            if (expert.verification_status.equals("APPROVED", ignoreCase = true)) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(text = "✓ Verified", color = darkPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Text(
                            text = expert.specialty,
                            color = Color.Gray,
                            fontSize = 13.sp
                        )

                        Text(
                            text = "License: ${expert.license_number}",
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = expert.bio,
                    color = textColor,
                    fontSize = 12.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Professional Practice Analytics Summary
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(end = 6.dp)
                        .background(Color.White, shape = RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text("Active Patients", color = Color.Gray, fontSize = 11.sp)
                        Text("${patientConsultations.size}", color = darkPink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 3.dp)
                        .background(Color.White, shape = RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text("Rating", color = Color.Gray, fontSize = 11.sp)
                        Text("4.9 ★", color = darkPink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(start = 6.dp)
                        .background(Color.White, shape = RoundedCornerShape(16.dp))
                        .padding(14.dp)
                ) {
                    Column {
                        Text("Status", color = Color.Gray, fontSize = 11.sp)
                        Text(availability.uppercase(), color = feminaPink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Doctor Practice Status Switcher
            FeminaCard {
                Text(
                    text = "Practice Availability Status",
                    color = textColor,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    listOf("AVAILABLE", "BUSY", "UNAVAILABLE").forEach { status ->
                        val isSelected = availability == status

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 4.dp)
                                .background(
                                    color = if (isSelected) feminaPink else Color(0xFFF5F5F5),
                                    shape = RoundedCornerShape(10.dp)
                                )
                                .clickable { availability = status }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = status.lowercase().replaceFirstChar { it.uppercase() },
                                color = if (isSelected) Color.White else textColor,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "Patient Consultation Queue",
                color = darkPink,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold
            )

            Spacer(modifier = Modifier.height(10.dp))

            when {
                isLoading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(30.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = darkPink)
                    }
                }

                patientConsultations.isEmpty() -> {
                    FeminaCard {
                        Text(
                            text = "No consultations scheduled yet.",
                            color = textColor,
                            fontSize = 14.sp
                        )
                    }
                }

                else -> {
                    patientConsultations.forEach { consultation ->
                        val patientName = patientNames[consultation.user_id] ?: "FEMINA Patient"
                        val existingAdvice = doctorNotes[consultation.consultation_id]

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .padding(16.dp)
                        ) {

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Patient: $patientName",
                                    color = textColor,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = consultation.status,
                                    color = if (consultation.status == "CONFIRMED") darkPink else feminaPink,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = "Scheduled: ${consultation.scheduled_at}",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Chief Concern: ${consultation.user_concern}",
                                color = textColor,
                                fontSize = 13.sp
                            )

                            if (existingAdvice != null) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFFFF0F4), shape = RoundedCornerShape(10.dp))
                                        .padding(10.dp)
                                ) {
                                    Column {
                                        Text(
                                            text = "🩺 Your Clinical Advice / Note:",
                                            color = darkPink,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = existingAdvice,
                                            color = textColor,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Interactive Professional Actions
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                if (consultation.status == "PENDING") {
                                    Button(
                                        onClick = {
                                            patientConsultations = patientConsultations.map {
                                                if (it.consultation_id == consultation.consultation_id) {
                                                    it.copy(status = "CONFIRMED")
                                                } else it
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.padding(end = 8.dp)
                                    ) {
                                        Text("Accept Request", color = Color.White, fontSize = 11.sp)
                                    }
                                }

                                Button(
                                    onClick = {
                                        editingConsultationId = if (editingConsultationId == consultation.consultation_id) null else consultation.consultation_id
                                        noteInputText = existingAdvice ?: ""
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFCE4EC)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Write Clinical Advice ✍️", color = darkPink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            // Expandable Clinical Note Editor
                            if (editingConsultationId == consultation.consultation_id) {
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = noteInputText,
                                    onValueChange = { noteInputText = it },
                                    modifier = Modifier.fillMaxWidth().height(100.dp),
                                    placeholder = { Text("Write medical recommendations, lifestyle advice, or prescription notes for patient...") },
                                    shape = RoundedCornerShape(12.dp)
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = {
                                        if (noteInputText.isNotBlank()) {
                                            doctorNotes = doctorNotes + (consultation.consultation_id to noteInputText)
                                        }
                                        editingConsultationId = null
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.align(Alignment.End)
                                ) {
                                    Text("Save Note for Patient", color = Color.White, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ============================================================
// CREATE ACCOUNT
// ============================================================
@Composable
fun CreateAccountScreen(
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val feminaPink = Color(0xFFFF7695)
    val textColor = Color(0xFF4A3540)

    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var agreedToTerms by remember { mutableStateOf(false) }

    var isChecking by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var accountCreated by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    fun attemptCreateAccount() {
        errorMessage = null

        when {
            fullName.isBlank() || email.isBlank() || password.isBlank() -> {
                errorMessage = "Please fill in all fields."
                return
            }
            !email.contains("@") || !email.contains(".") -> {
                errorMessage = "Please enter a valid email address."
                return
            }
            password.length < 6 -> {
                errorMessage = "Password must be at least 6 characters."
                return
            }
            password != confirmPassword -> {
                errorMessage = "Passwords don't match."
                return
            }
            !agreedToTerms -> {
                errorMessage = "Please agree to the Terms & Privacy Policy."
                return
            }
        }

        isChecking = true

        coroutineScope.launch {
            try {
                // Real check against your live database - confirms
                // this email isn't already registered.
                val existingUsers = RetrofitClient.apiService.getUsers()
                val alreadyExists = existingUsers.any {
                    it.email.equals(email.trim(), ignoreCase = true)
                }

                if (alreadyExists) {
                    errorMessage = "An account with this email already exists."
                    isChecking = false
                } else {
                    delay(600)
                    isChecking = false
                    accountCreated = true
                }
            } catch (e: Exception) {
                errorMessage = "Couldn't reach the server. Check your connection."
                isChecking = false
            }
        }
    }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "Create Account", onBack = onBack)

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Preview screen - checks live emails, but does not yet save new accounts to the database.",
                color = Color.Gray,
                fontSize = 12.sp,
                modifier = Modifier.padding(start = 12.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            if (accountCreated) {

                FeminaCard {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(70.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFCE4EC)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "✓",
                                    color = darkPink,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "Account Created!",
                                color = textColor,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "Welcome to FEMINA, $fullName.",
                                color = Color.Gray,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center
                            )

                            Spacer(modifier = Modifier.height(18.dp))

                            Button(
                                onClick = onBack,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(text = "CONTINUE", color = Color.White)
                            }
                        }
                    }
                }
            } else {

                FeminaCard {

                    Text(
                        text = "Join the community",
                        color = textColor,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    FormField(
                        label = "Full Name",
                        value = fullName,
                        onValueChange = { fullName = it; errorMessage = null },
                        placeholder = "Your full name"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    FormField(
                        label = "Email",
                        value = email,
                        onValueChange = { email = it; errorMessage = null },
                        placeholder = "you@example.com"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Password",
                            color = textColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = password,
                            onValueChange = { password = it; errorMessage = null },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("At least 6 characters") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(12.dp),
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                unfocusedContainerColor = Color(0xFFFAFAFA),
                                focusedContainerColor = Color.White
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Column(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = "Confirm Password",
                            color = textColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        OutlinedTextField(
                            value = confirmPassword,
                            onValueChange = { confirmPassword = it; errorMessage = null },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Re-enter your password") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            shape = RoundedCornerShape(12.dp),
                            colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                                unfocusedContainerColor = Color(0xFFFAFAFA),
                                focusedContainerColor = Color.White
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable { agreedToTerms = !agreedToTerms }
                    ) {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (agreedToTerms) feminaPink else Color(0xFFF5F5F5)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (agreedToTerms) {
                                Text(text = "✓", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Text(
                            text = "I agree to the Terms & Privacy Policy",
                            color = textColor,
                            fontSize = 13.sp
                        )
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = Color(0xFFC62828),
                            fontSize = 13.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { attemptCreateAccount() },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isChecking,
                        colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isChecking) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        } else {
                            Text(text = "CREATE ACCOUNT", color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun InstructionsScreen(
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val feminaPink = Color(0xFFFF7695)
    val textColor = Color(0xFF4A3540)

    val steps = listOf(
        InstructionStep(
            icon = Icons.Default.Home,
            title = "Home",
            description = "Your starting point. Search the community, see a quick wellness check-in, and scroll through real posts shared by other members."
        ),
        InstructionStep(
            icon = Icons.Default.FavoriteBorder,
            title = "Mood Tracker",
            description = "Tap 'Open Mood Tracker' on Home to log how you're feeling, note any symptoms, and write a private note about your day."
        ),
        InstructionStep(
            icon = Icons.Default.Flag,
            title = "Goals",
            description = "Small daily habits you can check off - sleep, movement, hydration, and time for yourself. Tap the circle next to a goal to mark it done."
        ),
        InstructionStep(
            icon = Icons.Default.Add,
            title = "Post",
            description = "Share something with the community. Write what's on your mind and tap POST to add it to the shared feed."
        ),
        InstructionStep(
            icon = Icons.Default.MailOutline,
            title = "Messages",
            description = "Chat with Femina AI for support, message a health professional through Find Experts, or talk with Friends in the community."
        ),
        InstructionStep(
            icon = Icons.Default.Person,
            title = "Profile",
            description = "Manage your account, update your medical history and notes, change settings, and control your privacy - all in one place."
        ),
        InstructionStep(
            icon = Icons.Default.FavoriteBorder,
            title = "Your Privacy",
            description = "Anything you write under Medical History & Notes stays private to you. You control what appears on your public profile under Account & Privacy."
        )
    )

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            ScreenHeader(title = "How to Use FEMINA", onBack = onBack)

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "A quick walkthrough of everything the app can do.",
                color = textColor,
                fontSize = 13.sp,
                modifier = Modifier.padding(start = 12.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            steps.forEachIndexed { index, step ->

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .background(
                            color = Color.White,
                            shape = RoundedCornerShape(18.dp)
                        )
                        .padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {

                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFCE4EC)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = step.icon,
                            contentDescription = step.title,
                            tint = darkPink,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${index + 1}. ",
                                color = feminaPink,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.ExtraBold
                            )

                            Text(
                                text = step.title,
                                color = textColor,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = step.description,
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            FeminaCard {
                Text(
                    text = "Ready to get started?",
                    color = darkPink,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "Head back to Home and try logging your mood for today.",
                    color = Color.Gray,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onBack,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = darkPink),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(text = "GOT IT", color = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// ============================================================
@Composable
fun NotificationsScreen(
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    // title, message, time, unread
    val notifications = remember {
        mutableStateListOf(
            NotificationItem(
                "Daily Check-In",
                "How are you feeling today? Take a moment to log your mood.",
                "10 minutes ago",
                true
            ),
            NotificationItem(
                "New reply on your post",
                "Anna Cruz replied to \"You are not alone in this journey\".",
                "1 hour ago",
                true
            ),
            NotificationItem(
                "Goal Reminder",
                "You're one goal away from completing today's set. Keep going!",
                "3 hours ago",
                false
            ),
            NotificationItem(
                "Welcome to FEMINA",
                "Your account is active. Explore the community and set your first goal.",
                "Yesterday",
                false
            ),
            NotificationItem(
                "New expert available",
                "Dr. Elena Garcia is now accepting consultations.",
                "2 days ago",
                false
            )
        )
    }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                ScreenHeader(title = "Notifications", onBack = onBack)

                Text(
                    text = "Mark all read",
                    color = darkPink,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable {
                        for (i in notifications.indices) {
                            notifications[i] = notifications[i].copy(unread = false)
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            notifications.forEachIndexed { index, item ->

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .background(
                            color = Color.White,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable {
                            notifications[index] = item.copy(unread = false)
                        }
                        .padding(16.dp),
                    verticalAlignment = Alignment.Top
                ) {

                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFCE4EC)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = darkPink,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.title,
                                color = textColor,
                                fontSize = 15.sp,
                                fontWeight = if (item.unread) FontWeight.Bold else FontWeight.Medium,
                                modifier = Modifier.weight(1f)
                            )

                            if (item.unread) {
                                Box(
                                    modifier = Modifier
                                        .size(9.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFF7695))
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = item.message,
                            color = Color.Gray,
                            fontSize = 13.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = item.time,
                            color = Color.Gray,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

data class NotificationItem(
    val title: String,
    val message: String,
    val time: String,
    val unread: Boolean
)

// ============================================================

// real FEMINA design yet (Edit Profile, Medical History & Notes,
// Settings, Help & Support, Account & Privacy). Swap the inside of
// this for the real design once you export those Figma screens -
// the back button and navigation wiring will keep working as-is.
@Composable
fun SimplePlaceholderScreen(
    title: String,
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {

                IconButton(
                    onClick = onBack
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = darkPink
                    )
                }

                Text(
                    text = title,
                    color = darkPink,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(25.dp))

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(20.dp)
            ) {

                Text(
                    text = "This screen is coming soon.",
                    color = textColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "We'll build the real $title screen here once the design is ready.",
                    color = Color.Gray,
                    fontSize = 14.sp
                )
            }
        }
    }
}

// Fetches the real "users" table from your Hostinger database through
// your API, and displays it. Use this to confirm the connection works
// before wiring real screens (Profile, Community, etc.) to live data.
@Composable
fun TestUsersScreen(
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val textColor = Color(0xFF4A3540)

    var users by remember { mutableStateOf<List<User>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        try {
            users = RetrofitClient.apiService.getUsers()
            isLoading = false
        } catch (e: Exception) {
            val rawMsg = e.localizedMessage ?: ""
            errorMessage = if (rawMsg.contains("BEGIN_ARRAY") && rawMsg.contains("BEGIN_OBJECT")) {
                "Hostinger Database Connection Notice:\n\nThe PHP script at index.php returned a JSON Error Object.\n\nPlease update your index.php file on Hostinger."
            } else {
                rawMsg
            }
            isLoading = false
        }
    }

    FeminaBackground {

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
        ) {

            Spacer(modifier = Modifier.height(30.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {

                IconButton(
                    onClick = onBack
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = darkPink
                    )
                }

                Text(
                    text = "Database Test",
                    color = darkPink,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            when {
                isLoading -> {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = darkPink)
                    }
                }

                errorMessage != null -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color.White,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Couldn't connect",
                            color = textColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = errorMessage ?: "",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    }
                }

                else -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {

                        Text(
                            text = "Connected! Showing ${users.size} users from your database:",
                            color = textColor,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )

                        Spacer(modifier = Modifier.height(15.dp))

                        users.forEach { user ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp)
                                    .background(
                                        color = Color.White,
                                        shape = RoundedCornerShape(14.dp)
                                    )
                                    .padding(14.dp)
                            ) {
                                Text(
                                    text = user.display_name,
                                    color = textColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )

                                Text(
                                    text = user.email,
                                    color = Color.Gray,
                                    fontSize = 12.sp
                                )

                                Text(
                                    text = user.account_status,
                                    color = darkPink,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
// Give each conversation its own real message history once you're
// ready to connect this to your backend/API.
@Composable
fun ChatScreen(
    title: String,
    subtitle: String,
    onBack: () -> Unit
) {

    val darkPink = Color(0xFF9B4D6A)
    val feminaPink = Color(0xFFFF7695)
    val textColor = Color(0xFF4A3540)

    val apiKey = "AQ.Ab8RN6LQXS_YCks8dW7D44xfC_fRfCnFKISb5ZB-MsQBEgNT1g"

    val systemPrompt = content {
        text("You are Femina AI, a compassionate, supportive, and knowledgeable health and wellness assistant for women. Provide warm, encouraging, safe, concise, and helpful responses.")
    }

    var messageText by remember {
        mutableStateOf("")
    }

    val messages = remember {
        mutableStateListOf<ChatBubbleMessage>()
    }

    var isTyping by remember { mutableStateOf(false) }

    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()

    fun sendMessage() {
        val text = messageText.trim()
        if (text.isEmpty()) return

        messages.add(ChatBubbleMessage(text = text, isMe = true))
        messageText = ""
        isTyping = true

        coroutineScope.launch {
            scrollState.animateScrollTo(scrollState.maxValue)

            if (title == "Femina AI") {
                try {
                    // Try live Gemini Cloud model if API key is valid
                    val modelsToTry = listOf(
                        "gemini-1.5-flash",
                        "gemini-2.0-flash",
                        "gemini-1.5-pro",
                        "gemini-1.5-flash-8b",
                        "gemini-pro"
                    )
                    var replyText: String? = null

                    if (apiKey.startsWith("AIzaSy")) {
                        for (modelName in modelsToTry) {
                            try {
                                val model = GenerativeModel(
                                    modelName = modelName,
                                    apiKey = apiKey,
                                    systemInstruction = systemPrompt
                                )
                                val response = model.generateContent(text)
                                if (response.text != null) {
                                    replyText = response.text
                                    break
                                }
                            } catch (_: Exception) {}
                        }
                    }

                    // General Conversational NLP Engine (Handles ANY random conversation accurately)
                    if (replyText == null) {
                        val promptTrimmed = text.trim()
                        val promptLower = promptTrimmed.lowercase()
                        val lastAiMsg = messages.lastOrNull { !it.isMe }?.text?.lowercase() ?: ""

                        replyText = when {
                            // 1. Contextual follow-up to AI questions ("no", "yes", etc.)
                            (promptLower == "no" || promptLower == "not yet" || promptLower == "no i haven't" || promptLower == "nope") && lastAiMsg.contains("mood tracker") ->
                                "That's completely fine! 🌸 Whenever you're ready, logging your symptoms in the Mood Tracker tab can help you spot patterns. In the meantime, try taking a 5-minute breather or drinking a cool glass of water. Would you like a quick tip to help you feel better right now?"

                            (promptLower == "yes" || promptLower == "yeah" || promptLower == "yep" || promptLower == "i did") && lastAiMsg.contains("mood tracker") ->
                                "That's fantastic! 💗 Tracking your mood daily is a wonderful way to understand your cycle and health patterns. Is there any specific symptom you'd like guidance on today?"

                            (promptLower == "no" || promptLower == "nope" || promptLower == "not really") ->
                                "No problem at all! I'm here to support you at your own pace. Let me know if you have any questions about symptoms, mood, sleep, or nutrition! 💕"

                            (promptLower == "yes" || promptLower == "yeah" || promptLower == "sure" || promptLower == "ok" || promptLower == "okay") ->
                                "Wonderful! What would you like to focus on today? We can talk about managing symptoms, improving sleep, boosting energy, or stress relief."

                            // 2. Specific Medical & Wellness Topics
                            promptLower.contains("dizzy") || promptLower.contains("dizziness") || promptLower.contains("lightheaded") || promptLower.contains("faint") || promptLower.contains("spinning") ->
                                "Feeling dizzy can be unsettling. Please sit or lie down safely, sip cool water, and take slow, deep breaths. Dizziness can be caused by dehydration, blood sugar dips, or hormonal shifts. If dizziness is severe or accompanied by chest pain or numbness, please consult a healthcare professional immediately."

                            promptLower.contains("headache") || promptLower.contains("migraine") || promptLower.contains("head hurt") ->
                                "Headaches and migraines are frequently tied to hormonal fluctuations, stress, or dehydration. Try resting in a dim, quiet room, applying a cool compress to your forehead, and drinking plenty of fluids."

                            promptLower.contains("moodswing") || promptLower.contains("mood swing") || promptLower.contains("moodswings") || promptLower.contains("want to be better") || promptLower.contains("feel better") || promptLower.contains("better") || promptLower.contains("irritable") || promptLower.contains("crying") ->
                                "I completely understand wanting to feel better 💗. Mood swings are very common during hormonal shifts. Be kind to yourself today. Gentle movement, staying hydrated, getting fresh air, and deep breathing can help restore balance. What is one small thing you can do for yourself today?"

                            promptLower.contains("mood") || promptLower.contains("sad") || promptLower.contains("anxious") || promptLower.contains("stress") || promptLower.contains("depressed") ->
                                "I hear you, and your feelings are completely valid 💗. Hormonal fluctuations can significantly impact mood and stress levels. Be gentle with yourself today. Have you logged your mood in the Mood Tracker tab?"

                            promptLower.contains("sleep") || promptLower.contains("insomnia") || promptLower.contains("tired") || promptLower.contains("fatigue") || promptLower.contains("exhausted") || promptLower.contains("energy") ->
                                "Rest is so crucial for recovery and hormonal balance. Try keeping your bedroom cool (65-68°F), dimming screens 1 hour before bed, and sipping warm chamomile tea to help signal your body to relax."

                            promptLower.contains("hot flash") || promptLower.contains("flash") || promptLower.contains("sweat") || promptLower.contains("night sweat") ->
                                "Hot flashes can be really uncomfortable! Here are quick natural tips:\n\n• Keep a cooling towel or spray nearby\n• Sip cool water throughout the day\n• Wear breathable cotton layers\n• Practice 5 minutes of deep, slow abdominal breathing to calm your nervous system."

                            promptLower.contains("period") || promptLower.contains("cramp") || promptLower.contains("pms") || promptLower.contains("cycle") || promptLower.contains("bleed") || promptLower.contains("menopause") || promptLower.contains("perimenopause") ->
                                "Hormonal cycles affect energy, mood, and physical comfort. Applying a warm heating pad for cramps, staying well-hydrated, and eating magnesium-rich foods (like dark chocolate, nuts, or spinach) can bring great relief!"

                            promptLower.contains("diet") || promptLower.contains("food") || promptLower.contains("nutrition") || promptLower.contains("eat") || promptLower.contains("bloat") || promptLower.contains("nausea") ->
                                "Focusing on whole foods, healthy fats (like avocados and walnuts), leafy greens, and lean protein supports steady blood sugar and hormonal health! Drinking peppermint tea can also ease bloating."

                            promptLower.contains("hello") || promptLower.contains("hi") || promptLower.contains("hey") ->
                                "Hello! I'm Femina AI 🌸. I'm here to support you with women's health, symptom management, nutrition, and daily encouragement. How are you feeling today?"

                            promptLower.contains("thanks") || promptLower.contains("thank you") || promptLower.contains("thankyou") || promptLower.contains("appreciate") ->
                                "You are so welcome! 💕 I'm always here whenever you need health tips or encouragement. Take good care of yourself today!"

                            // 3. General NLP Sentence Analyzer (Handles ANY Random Statement, Question, or Emotion)
                            promptLower.contains("?") || promptLower.startsWith("what") || promptLower.startsWith("how") || promptLower.startsWith("why") || promptLower.startsWith("can") || promptLower.startsWith("should") || promptLower.startsWith("is") || promptLower.startsWith("are") ->
                                "That's a thoughtful question regarding \"${promptTrimmed.take(60)}\"! From a wellness perspective, listening to your body, maintaining balanced hydration, and giving yourself space to rest are key. Would you like more specific tips on this?"

                            promptLower.contains("feel") || promptLower.contains("feeling") || promptLower.contains("am") || promptLower.contains("experiencing") ->
                                "Thank you for sharing how you're feeling (\"${promptTrimmed.take(60)}\") 💗. Acknowledging your physical and emotional state is a powerful first step in self-care. Be gentle with yourself today."

                            else ->
                                "Thank you for sharing: \"${promptTrimmed.take(60)}\". Every reflection helps you stay mindful of your wellness journey. How can I best support you with your health or symptoms today?"
                        }
                    }

                    messages.add(ChatBubbleMessage(text = replyText, isMe = false))
                } catch (e: Exception) {
                    messages.add(
                        ChatBubbleMessage(
                            text = "Thank you for reaching out! Femina AI is here for you. How can I assist with your wellness today?",
                            isMe = false
                        )
                    )
                } finally {
                    isTyping = false
                    scrollState.animateScrollTo(scrollState.maxValue)
                }
            } else {
                delay(1200)

                val reply = when (title) {
                    "Find Experts" -> "Thanks for reaching out! A health professional will review your message and reply shortly."

                    else -> listOf(
                        "Hey! Thanks for the message 😊",
                        "I hear you, let's talk more about it.",
                        "That's great to hear!",
                        "Sending you support 💗"
                    ).random()
                }

                messages.add(ChatBubbleMessage(text = reply, isMe = false))
                isTyping = false
                scrollState.animateScrollTo(scrollState.maxValue)
            }
        }
    }

    FeminaBackground {

        Column(
            modifier = Modifier.fillMaxSize()
        ) {

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    IconButton(
                        onClick = onBack
                    ) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back",
                            tint = darkPink
                        )
                    }

                    Column {
                        Text(
                            text = title,
                            color = darkPink,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Text(
                            text = if (isTyping) "typing..." else subtitle,
                            color = if (isTyping) feminaPink else textColor,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 20.dp)
            ) {

                if (messages.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                color = Color.White,
                                shape = RoundedCornerShape(18.dp)
                            )
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Say hello to start the conversation with $title.",
                            color = Color.Gray,
                            fontSize = 13.sp
                        )
                    }
                } else {
                    messages.forEach { message ->
                        ChatBubble(
                            message = message,
                            darkPink = darkPink,
                            feminaPink = feminaPink,
                            textColor = textColor
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    if (isTyping) {
                        Row(
                            modifier = Modifier
                                .background(
                                    color = Color.White,
                                    shape = RoundedCornerShape(16.dp)
                                )
                                .padding(horizontal = 14.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = "· · ·",
                                color = Color.Gray,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {

                OutlinedTextField(
                    value = messageText,
                    onValueChange = {
                        messageText = it
                    },
                    modifier = Modifier.weight(1f),
                    placeholder = {
                        Text("Type a message...")
                    },
                    shape = RoundedCornerShape(20.dp),
                    singleLine = true
                )

                Spacer(modifier = Modifier.width(8.dp))

                Button(
                    onClick = { sendMessage() },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = darkPink
                    ),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text(
                        text = "Send",
                        color = Color.White
                    )
                }
            }
        }
    }
}

data class ChatBubbleMessage(
    val text: String,
    val isMe: Boolean
)

@Composable
fun ChatBubble(
    message: ChatBubbleMessage,
    darkPink: Color,
    feminaPink: Color,
    textColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.isMe) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .background(
                    color = if (message.isMe) feminaPink else Color.White,
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (message.isMe) 16.dp else 4.dp,
                        bottomEnd = if (message.isMe) 4.dp else 16.dp
                    )
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .widthIn(max = 260.dp)
        ) {
            Text(
                text = message.text,
                color = if (message.isMe) Color.White else textColor,
                fontSize = 14.sp
            )
        }
    }
}