package com.example.femina.network

data class Consultation(
    val consultation_id: String,
    val user_id: String,
    val expert_id: String,
    val scheduled_at: String,
    val status: String,
    val user_concern: String
)