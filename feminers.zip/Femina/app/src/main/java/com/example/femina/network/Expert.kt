package com.example.femina.network

data class Expert(
    val expert_id: String,
    val name: String,
    val email: String,
    val specialty: String,
    val license_number: String,
    val license_document_url: String,
    val id_document_url: String,
    val verification_status: String,
    val bio: String,
    val profile_photo_url: String?,
    val created_at: String,
    val availability_status: String
)