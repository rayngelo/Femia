package com.example.femina.network

import retrofit2.http.GET
import retrofit2.http.Query

interface FeminaApiService {

    // Matches: http://inovex.site/Femina/index.php?table=users
    @GET("index.php")
    suspend fun getUsers(
        @Query("table") table: String = "users"
    ): List<User>

    // Matches: http://inovex.site/Femina/index.php?table=forum_posts
    @GET("index.php")
    suspend fun getForumPosts(
        @Query("table") table: String = "forum_posts"
    ): List<ForumPost>

    // Matches: http://inovex.site/Femina/index.php?table=forum_comments
    @GET("index.php")
    suspend fun getForumComments(
        @Query("table") table: String = "forum_comments"
    ): List<ForumComment>

    // Matches: http://inovex.site/Femina/index.php?table=experts
    @GET("index.php")
    suspend fun getExperts(
        @Query("table") table: String = "experts"
    ): List<Expert>

    // Matches: http://inovex.site/Femina/index.php?table=consultations
    @GET("index.php")
    suspend fun getConsultations(
        @Query("table") table: String = "consultations"
    ): List<Consultation>

    // Same endpoint, different table - reuse this pattern for
    // profiles, educational_resources, etc. once we need them.
    // Example:
    // @GET("index.php")
    // suspend fun getProfiles(
    //     @Query("table") table: String = "profiles"
    // ): List<Profile>
}