package com.example.femina.network

data class User(
    val user_id: String,
    val display_name: String,
    val email: String,
    val account_status: String,
    val created_at: String
)