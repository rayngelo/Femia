package com.example.femina.network

data class ForumComment(
    val comment_id: String,
    val post_id: String,
    val user_id: String,
    val content: String,
    val created_at: String
)