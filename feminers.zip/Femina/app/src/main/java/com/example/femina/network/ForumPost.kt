package com.example.femina.network

data class ForumPost(
    val post_id: String,
    val user_id: String,
    val title: String,
    val content: String,
    val moderation_status: String,
    val created_at: String
)